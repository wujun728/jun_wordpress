//DBMAPS
var doroodo_db={sy_file:'syFile',sy_user:'syUser',t_sb_state_data:'tsbStateData',sy_module:'syModule',sy_debug:'syDebug',sy_parameter:'syParameter',sy_debug_state:'syDebugState',sy_demo_gridtochart:'syDemoGridtochart',sy_demo_treeiframe:'syDemoTreeiframe',sy_chart:'syChart',sy_parameter_used:'syParameterUsed',sy_role:'syRole',sy_assembly:'syAssembly',sy_log:'syLog',sy_design:'syDesign',sy_demo_datetree:'syDemoDatetree',sy_notice:'syNotice',sy_webmodal:'syWebmodal',sy_tablefield_remarks:'syTablefieldRemarks',t_sb_eq:'tsbEq',sy_project:'syProject',sy_organ:'syOrgan'}
//DBMAPE
