package org.easy.dao;

import org.easy.entity.Employee;

import java.util.List;

public interface EmployeeMapper {

    /**
     * 动态字段,写入数据库记录
     *
     * @param record
     */
    int insertSelective(Employee record);

    /**
     * 根据主键删除数据库的记录
     *
     * @param id
     */
    int deleteByPrimaryKey(Integer id);

    /**
     * 动态字段,根据主键来更新符合条件的数据库记录
     *
     * @param record
     */
    int updateByPrimaryKeySelective(Employee record);

    /**
     * 根据指定主键获取一条数据库记录
     *
     * @param id
     */
    Employee selectByPrimaryKey(Integer id);

    /**
     * 动态字段,根据条件查询符合条件的数据库记录
     *
     * @param record
     */
    List<Employee> queryEntityByCondition(Employee record);

    /**
     * 动态字段,根据条件查询符合条件的数据库记录总数
     *
     * @param record
     */
    int queryCountByCondition(Employee record);

    int insertBat(List<Employee> list);

}