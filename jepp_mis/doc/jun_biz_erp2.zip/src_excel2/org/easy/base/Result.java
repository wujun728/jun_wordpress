package org.easy.base;

import java.io.Serializable;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class Result<T> implements Serializable {
    public static final String SUCCESS_CODE = "00000000";
    private boolean success;
    private String code;
    private String message;
    private T data;

    public Result() {
    }

    public boolean isSuccess() {
        return this.success;
    }

    public Result<T> setSuccess(boolean success) {
        this.success = success;
        return this;
    }

    public String getCode() {
        return this.code;
    }

    public Result<T> setCode(String code) {
        this.code = code;
        return this;
    }

    public String getMessage() {
        return this.message;
    }

    public Result<T> setMessage(String message) {
        this.message = message;
        return this;
    }

    public T getData() {
        return this.data;
    }

    public Result<T> setData(T data) {
        this.data = data;
        return this;
    }

    public static <T> Result<T> wrapSuccessfulResult(T data) {
        return (new Result()).setSuccess(true).setCode("00000000").setData(data);
    }

    public static <T> Result<T> wrapSuccessfulResult(String message, T data) {
        return (new Result()).setSuccess(true).setCode("00000000").setMessage(message).setData(data);
    }

    public static <T> Result<T> wrapErrorResult(T data) {
        return (new Result()).setSuccess(false).setCode("00000000").setData(data);
    }

    public static <T> Result<T> wrapErrorResult(String message, T data) {
        return (new Result()).setSuccess(false).setCode("00000000").setMessage(message).setData(data);
    }

    public boolean equals(Object o) {
        if(this == o) {
            return true;
        } else if(o != null && this.getClass() == o.getClass()) {
            Result result = (Result)o;
            return (new EqualsBuilder()).append(this.isSuccess(), result.isSuccess()).append(this.getCode(), result.getCode()).append(this.getMessage(), result.getMessage()).append(this.getData(), result.getData()).isEquals();
        } else {
            return false;
        }
    }

    public int hashCode() {
        return (new HashCodeBuilder(17, 37)).append(this.isSuccess()).append(this.getCode()).append(this.getMessage()).append(this.getData()).toHashCode();
    }

    public String toString() {
        return (new ToStringBuilder(this)).append("success", this.success).append("code", this.code).append("message", this.message).append("data", this.data).toString();
    }
}
