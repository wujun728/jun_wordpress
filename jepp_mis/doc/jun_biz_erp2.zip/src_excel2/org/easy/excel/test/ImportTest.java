package org.easy.excel.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.List;

import org.easy.excel.ExcelContext;
import org.easy.excel.test.model.BookModel;
import org.easy.excel.test.model.StudentModel;
import org.easy.excel.vo.ExcelImportResult;
import org.junit.Test;
/**
 * Excel导入测试
 * @author zengshan
 *
 */
public class ImportTest {
	
	// 测试时文件磁盘路径
	private static String path = "C:/Users/Administrator/Desktop/stu.xlsx";
	// 配置文件路径
	private static ExcelContext context = new ExcelContext("excel/excel-config.xml");
	// Excel配置文件中配置的id
	private static String excelId = "student";
	
	/**
	 * 导入Excel,使用了org.easy.excel.test.ExportTest.testExportCustomHeader()方法生成的Excel
	 * @throws Exception
	 */
	@Test
	public void testImport()throws Exception{
		InputStream fis = new FileInputStream(path);
		//第二个参数需要注意,它是指标题索引的位置,可能你的前几行并不是标题,而是其他信息,
		//比如数据批次号之类的,关于如何转换成javaBean,具体参考配置信息描述
		ExcelImportResult result = context.readExcel(excelId, 2, fis);
		System.out.println(result.getHeader());
		List<StudentModel> stus = result.getListBean();
		for(StudentModel stu:stus){
			System.out.println(stu);
			BookModel book = stu.getBook();
			System.out.println(book);
			if(book!=null){
				System.out.println(book.getAuthor());
			}
		}
		
		//这种方式和上面的没有任何区别,底层方法默认标题索引为0
		//context.readExcel(excelId, fis);
	}



	public static void main(String[] args) {
		File f = null;
		try{
			// creates temporary file
			f = File.createTempFile("tmp", ".txt");

			// prints absolute path
			System.out.println("File path: "+f.getAbsolutePath());

			// deletes file when the virtual machine terminate
			f.deleteOnExit();

			// creates temporary file
			f = File.createTempFile("tmp", ".xlsx");

			// prints absolute path
			System.out.print("File path: "+f.getAbsolutePath());

			// deletes file when the virtual machine terminate
			f.deleteOnExit();

		}catch(Exception e){
			// if any error occurs
			e.printStackTrace();
		}
	}
	
	
		
}
