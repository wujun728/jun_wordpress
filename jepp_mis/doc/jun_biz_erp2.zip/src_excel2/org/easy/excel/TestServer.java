package org.easy.excel;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.webapp.WebAppContext;

/**
 * Created by zengshan on 16/6/6.
 */
public class TestServer {
    public static void main(String[] args) {
        Server server = new Server(8088);
        WebAppContext context = new WebAppContext();
        context.setContextPath("/");
        context.setDescriptor("./src/main/webapp/WEB-INF/web.xml");
        context.setResourceBase("./src/main/webapp");
        //解决静态资源缓存后再ide里面不能修改问题
//        context.setDefaultsDescriptor("./src/test/resources/webdefault.xml");
        context.setParentLoaderPriority(true);
        server.setHandler(context);

        try {
            server.start();
            server.join();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
