package org.easy.common;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.springframework.beans.BeanUtils;

import java.util.List;
import java.util.Map;

/**
 * 不同实体相同属性之间的相互转换
 * Created by zengshan on 16/6/22.
 */
public class BdUtil {

    public static <E, O> O e2O(E request, Class<O> cls) {
        if (null == request) return null;
        O result;
        try {
            result = cls.newInstance();
            BeanUtils.copyProperties(request, result);
        } catch (Exception e) {
            throw new IllegalArgumentException("对象copy失败，请检查相关module", e);
        }
        return result;
    }

    public static <E, O> List<O> e2OList(List<E> request, Class<O> cls) {
        List<O> result = Lists.newArrayList();
        if (request == null) return result;
        for (E obj : request) {
            result.add(e2O(obj, cls));
        }
        return result;
    }

    public static <E, O, K> Map<K, O> e2OMap(Map<K, E> request, Class<O> cls) {
        Map<K, O> result = Maps.newHashMap();
        for (Map.Entry<K, E> item : request.entrySet()) {
            K key = item.getKey();
            E val = item.getValue();
            result.put(key, e2O(val, cls));
        }
        return result;
    }
}
