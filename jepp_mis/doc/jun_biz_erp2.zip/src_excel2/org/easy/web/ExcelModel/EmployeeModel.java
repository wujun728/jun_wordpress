package org.easy.web.ExcelModel;

import lombok.Data;

import java.util.Date;

/**
 * 员工类
 *
 * @author zengshan
 */
@Data
public class EmployeeModel {

    /**
     * ID
     */
    protected Integer id;
    /**
     * 创建时间
     */
    protected Date createTime;
    /**
     * 姓名
     */
    private String name;
    /**
     * 性别 0:男 1:女
     */
    private Integer sex;
    /**
     * 年龄
     */
    private Integer age;
    /**
     * 手机号
     */
    private String mobile;
    /**
     * 状态 0:在职
     *     1:离职
     */
    private Integer status;


}
