package org.easy.web.controller;

import lombok.extern.slf4j.Slf4j;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.easy.base.Result;
import org.easy.common.BdUtil;
import org.easy.entity.Employee;
import org.easy.excel.ExcelContext;
import org.easy.excel.ExcelException;
import org.easy.excel.ExcelHeader;
import org.easy.excel.vo.ExcelDefinition;
import org.easy.service.EmployeeService;
import org.easy.util.ExcelUtil;
import org.easy.util.StringUtil;
import org.easy.web.ExcelModel.EmployeeModel;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by zengshan on 16/7/24.
 */
@Controller
@RequestMapping("/excel")
@Slf4j
public class ExcelController {

    @Resource
    private EmployeeService employeeService;

    @Resource
    private ExcelContext excelContext;

    @RequestMapping("/import")
    @ResponseBody
    public Result importExcel(@RequestParam(value = "file", required = true) MultipartFile file) throws Exception {
        Boolean excel = StringUtil.isExcel(file.getOriginalFilename());
        if (!excel){
            return Result.wrapErrorResult("该文件不是Excel格式");
        }
        InputStream fis = file.getInputStream();
        ExcelContext context = new ExcelContext("excel/config.xml");
        ExcelUtil<EmployeeModel> excelUtil = new ExcelUtil(excelContext, "employee");
        List<EmployeeModel> stus;
        try {
            stus = excelUtil.importExcel(1, fis);
        } catch (ExcelException e) {//这里主动返回错误信息
            return Result.wrapErrorResult(e.getMessage());
        }
        List<Employee> list=BdUtil.e2OList(stus,Employee.class);
//        employeeService.insertBat(list);
//        for (EmployeeModel e:stus){
//            Employee employee= BdUtil.e2O(e,Employee.class);
//            employeeService.insertSelective(employee);
//        }
        return Result.wrapSuccessfulResult(list);
    }

    @RequestMapping("/export")
    public void exportExcel(HttpServletRequest request, HttpServletResponse response) throws Exception {
//        ExcelContext context = new ExcelContext("excel/config.xml");
        ExcelUtil<EmployeeModel> excelUtil = new ExcelUtil(excelContext, "employee");
        final List<EmployeeModel> list = getEmployeeList();
        List<String> specifyFields = new ArrayList<String>();
//        specifyFields.add("sex");
//        specifyFields.add("name");
//        specifyFields.add("age");

        ExcelHeader header=new ExcelHeader() {
            public void buildHeader(Sheet sheet, ExcelDefinition excelDefinition, List<?> beans,Workbook workbook) {
                // 设置第一行样式
                CellStyle style1 = workbook.createCellStyle();
                // 水平居中
                style1.setAlignment(HSSFCellStyle.ALIGN_CENTER);
                // 垂直居中
                style1.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
                // 设置字体 大小
                Font font1 = workbook.createFont();
                font1.setFontHeightInPoints((short) 18);
                style1.setFont(font1);

                //第一行数据
                Row row1 = sheet.createRow(0);
                Cell cell1 = row1.createCell(0);
                cell1.setCellValue("共导出【"+list.size()+"】条数据");
                // 行高
                row1.setHeight((short) 700);
                cell1.setCellStyle(style1);

                //合并单元格
                CellRangeAddress region = new CellRangeAddress(0, 0, 0, 2);
                sheet.addMergedRegion(region);
            }
        };
        excelUtil.exportExcel1(response,list, header,specifyFields,"员工信息");
    }


    List<EmployeeModel> getEmployeeList() {
        List<EmployeeModel> list = new ArrayList<EmployeeModel>();
        int count = 1;
        while (count < 1001) {
            EmployeeModel emp = new EmployeeModel();
            emp.setId(count);
            emp.setCreateTime(new Date());
            emp.setMobile("18064082246");
            emp.setName("张三" + count);
            if (count % 2 == 0) {
                emp.setAge(22);
                emp.setSex(1);
                emp.setStatus(0);
            } else {
                emp.setAge(23);
                emp.setSex(0);
                emp.setStatus(1);
            }
            list.add(emp);
            count++;

        }
        return list;
    }

}
