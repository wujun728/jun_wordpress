package org.easy.service;

import org.easy.entity.Employee;

import java.util.List;

/**
 * Created by zengshan on 16/7/24.
 */
public interface EmployeeService {
    /**
     *  动态字段,写入数据库记录
     *
     * @param record
     */
    int insertSelective(Employee record);
    int insertBat(List<Employee> list);
    void insertMongoDB(List<Employee> list);

}
