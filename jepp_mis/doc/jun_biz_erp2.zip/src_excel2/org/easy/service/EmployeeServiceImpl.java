package org.easy.service;

import org.easy.dao.EmployeeMapper;
import org.easy.entity.Employee;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by zengshan on 16/7/24.
 */
@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Resource
    private EmployeeMapper employeeMapper;

    private static String USER_COLLECTION = "employee";

    @Resource
    MongoTemplate mongoTemplate;

    public int insertSelective(Employee record) {
        return employeeMapper.insertSelective(record);
    }

    public int insertBat(List<Employee> list) {
        return employeeMapper.insertBat(list);
    }

    public void insertMongoDB(List<Employee> list) {
        mongoTemplate.insertAll(list);
    }

}
