package org.easy.util;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.easy.excel.ExcelContext;
import org.easy.excel.ExcelHeader;
import org.easy.excel.vo.ExcelDefinition;
import org.easy.excel.vo.ExcelImportResult;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;
import java.util.Collections;
import java.util.List;

/**
 * Excel 导出方法调用(主)
 * Created by zengshan on 16/7/23.
 */
public class ExcelUtil<T> {

    //创建excel上下文实例,配置文件路径
    private ExcelContext context;
    //Excel配置文件中配置的id
    private String excelId;

    public ExcelUtil(ExcelContext context, String excelId) {
        this.context = context;
        this.excelId = excelId;
    }

    /**
     * 导出 excel
     *
     * @param list 导出结果集
     * @param path
     * @throws Exception
     */
    public void exportExcel(List<T> list, String path) throws Exception {
        File file = new File(path);
        if (!file.getParentFile().exists()) {//文件上级目录是否存在,不存在则创建上级目录
            file.getParentFile().mkdirs();
        }
        OutputStream ops = new FileOutputStream(path);
        Workbook workbook = context.createExcel(excelId, list);
        workbook.write(ops);
        ops.close();
        workbook.close();
    }

    /**
     * 导出Excel并下载
     * @param response
     * @param list     结果集,null默认导出模板
     * @param header   自定义表头,null默认无
     * @param specifyFields 导出字段,null导出所有字段
     * @param fileName  下载的文件名
     */
    public void exportExcel1(HttpServletResponse response, List<T> list,ExcelHeader header, List<String> specifyFields, String fileName) {
        File file = null;
        OutputStream ops = null;
        OutputStream out = null;
        Workbook workbook = null;
        try {
            /**
             * Step1:创建临时xlsx文件
             */
            file = File.createTempFile("tmp", ".xlsx");
            /**
             * Step2:导出数据写入临时xlsx文件
             */
            String path = file.getAbsolutePath();
            ops = new FileOutputStream(path);
            //获取POI创建结果
            if (list != null && !list.isEmpty()) {
                workbook = context.createExcel(excelId, list, header, specifyFields);
//                workbook = context.createExcel(excelId, list);
            } else {//查询结果为空,导出模板
                workbook = context.createExcelTemplate(excelId, header, specifyFields);
            }
            workbook.write(ops);
            /**
             * Step3:下载临时xlsx文件
             */
            response.reset();
            response.setContentType("application/octet-stream; charset=utf-8");
            fileName = URLEncoder.encode(fileName + ".xlsx", "UTF-8");
            response.setHeader("Content-Disposition", "attachment; filename=" + fileName);
            out = response.getOutputStream();
            out.write(FileUtils.readFileToByteArray(file));
            out.flush();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            file.deleteOnExit();//临时文件若存在,则删除
            try {
                if (ops != null) {
                    ops.close();
                }
                if (workbook != null) {
                    workbook.close();
                }
                if (out != null) {
                    out.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }

    /**
     * 导出模板
     *
     * @param path
     * @throws Exception
     */
    public void exportExcelTemplate(String path) throws Exception {
        OutputStream ops = new FileOutputStream(path);
        Workbook workbook = context.createExcelTemplate(excelId, null, null);
        workbook.write(ops);
        ops.close();
        workbook.close();
    }


    /**
     * @param startRow 头部从第几行开始导入
     * @param fis      文件流
     * @return
     * @throws Exception
     */
    public List<T> importExcel(int startRow, InputStream fis) throws Exception {
        //第二个参数需要注意,它是指标题索引的位置,可能你的前几行并不是标题,而是其他信息,
        //比如数据批次号之类的,关于如何转换成javaBean,具体参考配置信息描述
        ExcelImportResult result = context.readExcel(excelId, startRow, fis);
//        System.out.println(result.getHeader());
        List<T> stus = result.getListBean();
        return stus;
        //这种方式和上面的没有任何区别,底层方法默认标题索引为0
        //context.readExcel(excelId, fis);
    }

    /***
     * 导出,自定义头信息
     *
     * @throws Exception
     */
    public void exportCustomHeader(List<T> list, String path) throws Exception {
        File file = new File(path);
        if (!file.getParentFile().exists()) {//文件上级目录是否存在,不存在则创建上级目录
            file.getParentFile().mkdirs();
        }
        OutputStream ops = new FileOutputStream(path);
        final List<T> T_List = list;
        Workbook workbook = context.createExcel(excelId, T_List, new ExcelHeader() {
            public void buildHeader(Sheet sheet, ExcelDefinition excelDefinition, List<?> beans,Workbook workbook) {
                Row row1 = sheet.createRow(0);
                Cell cell = row1.createCell(0);
                cell.setCellValue("共导出【" + T_List.size() + "】条数据");
//                Row row2 = sheet.createRow(1);
//                Cell cell2 = row2.createCell(0);
//                cell2.setCellValue("本次批次号为:XXX");
            }
        });
        workbook.write(ops);
        ops.close();
        workbook.close();
    }


}
